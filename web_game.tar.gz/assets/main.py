import pygame
import random
import json
import os
import sys
import asyncio
from pygame import mixer

# ----------------------------------------------------
# HÀM XỬ LÝ ĐƯỜNG DẪN TÀI NGUYÊN (CHO WEB & EXE)
# ----------------------------------------------------
def resource_path(relative_path):
    """Lấy đường dẫn tuyệt đối cho tài nguyên, hỗ trợ PyInstaller & Pygbag Web"""
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


async def main():
    # Khởi tạo Pygame & Mixer với tần số mẫu chuẩn Web
    pygame.init()
    try:
        mixer.pre_init(44100, -16, 2, 512)
        mixer.init()
    except Exception as e:
        print(f"Lỗi khởi tạo Mixer âm thanh: {e}")

    # Cho phép nhấn giữ phím & gõ tiếng Việt
    pygame.key.set_repeat(250, 50)
    pygame.key.start_text_input()

    # ----------------------------------------------------
    # CẤU HÌNH MÀN HÌNH ÁO 16:9 (VIRTUAL RESOLUTION)
    # ----------------------------------------------------
    VIRTUAL_WIDTH = 960
    VIRTUAL_HEIGHT = 540

    is_fullscreen = False
    screen = pygame.display.set_mode((VIRTUAL_WIDTH, VIRTUAL_HEIGHT), pygame.RESIZABLE)
    canvas = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT))

    clock = pygame.time.Clock()
    TARGET_FPS = 144

    # Title and Icon
    pygame.display.set_caption("Word Shooter")
    try:
        icon = pygame.image.load(resource_path('image/icon.png'))
        pygame.display.set_icon(icon)
    except Exception as e:
        print(f"Lỗi tải icon: {e}")

    # Background
    try:
        raw_background = pygame.image.load(resource_path('image/background.jpg')).convert()
        background = pygame.transform.scale(raw_background, (VIRTUAL_WIDTH, VIRTUAL_HEIGHT))
    except Exception as e:
        print(f"Lỗi tải background: {e}")
        raw_background = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT))
        raw_background.fill((10, 10, 30))
        background = raw_background

    # Sound Effects
    has_music = False
    try:
        mixer.music.load(resource_path('sound/backgound.ogg'))
        has_music = True
    except Exception as e:
        print(f"Lỗi tải nhạc nền: {e}")

    def load_sound(path):
        try:
            return mixer.Sound(resource_path(path))
        except Exception as e:
            print(f"Lỗi tải âm thanh {path}: {e}")
            return None

    laser_sound = load_sound('sound/laser.ogg')
    explosion_sound = load_sound('sound/explosion.ogg')
    gameover_sound = load_sound('sound/gameover.ogg')
    gamewin_sound = load_sound('sound/gamewin.ogg')

    audio_unlocked = False

    def unlock_audio():
        nonlocal audio_unlocked
        if not audio_unlocked:
            safe_play_music()
            audio_unlocked = True

    def safe_play_sound(sound_obj):
        if sound_obj:
            try:
                sound_obj.play()
            except Exception:
                pass

    def safe_play_music():
        if has_music:
            try:
                mixer.music.play(-1)
            except Exception:
                pass

    def safe_stop_music():
        if has_music:
            try:
                mixer.music.stop()
            except Exception:
                pass

    # FONTS
    font_path = resource_path('ChakraPetch-BoldItalic.ttf')

    def get_font(size):
        if os.path.exists(font_path):
            try:
                return pygame.font.Font(font_path, size)
            except Exception:
                pass
        return pygame.font.SysFont('arial', size)

    font = get_font(32)
    word_font = get_font(24)
    small_font = get_font(18)
    guide_font = get_font(20)
    tiny_font = get_font(14)
    over_font = get_font(56)
    win_font = get_font(56)

    # ----------------------------------------------------
    # HÀM HỖ TRỢ TÍNH TỌA ĐỘ MÀN HÌNH VÀ CHUỘT
    # ----------------------------------------------------
    def get_render_offset_and_scale():
        screen_w, screen_h = screen.get_size()
        scale = min(screen_w / VIRTUAL_WIDTH, screen_h / VIRTUAL_HEIGHT)
        new_w = int(VIRTUAL_WIDTH * scale)
        new_h = int(VIRTUAL_HEIGHT * scale)
        off_x = (screen_w - new_w) // 2
        off_y = (screen_h - new_h) // 2
        return off_x, off_y, scale, new_w, new_h

    def scale_mouse_pos(pos):
        off_x, off_y, scale, _, _ = get_render_offset_and_scale()
        mx, my = pos
        if scale == 0:
            return 0, 0
        virtual_x = (mx - off_x) / scale
        virtual_y = (my - off_y) / scale
        return virtual_x, virtual_y

    # ----------------------------------------------------
    # QUẢN LÝ DỮ LIỆU TỪ VỰNG
    # ----------------------------------------------------
    VOCAB_FILE = "vocab.json"

    default_vocab_list = [
        {"en": "sniff", "vi": "hít, ngửi"},
        {"en": "furry", "vi": "lông thú"},
        {"en": "totter (up)", "vi": "bước đi loạng choạng"},
        {"en": "pale", "vi": "tái nhợt, nhợt nhạt"},
        {"en": "triumph", "vi": "niềm vui, hân hoan"},
        {"en": "coffin", "vi": "quan tài"},
        {"en": "railing", "vi": "lan can"},
        {"en": "treacherous", "vi": "nguy hiểm(xảo quyệt)"},
        {"en": "pauper", "vi": "người ăn xin"},
        {"en": "come to terms with", "vi": "chấp nhận 1 điều gì đó"},
    ]

    def load_data():
        speed = 1.8
        vocab = list(default_vocab_list)
        if os.path.exists(VOCAB_FILE):
            try:
                with open(VOCAB_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        vocab = data.get("vocab", list(default_vocab_list))
                        speed = float(data.get("speed", 1.8))
                    elif isinstance(data, list) and len(data) > 0:
                        vocab = data
            except Exception as e:
                print(f"Lỗi khi đọc file vocab.json: {e}")
        if speed <= 0:
            speed = 1.8
        return vocab, speed

    def save_data(vocab_list, speed_val):
        try:
            data = {
                "speed": max(0.1, float(speed_val)),
                "vocab": vocab_list
            }
            with open(VOCAB_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"Lỗi khi lưu file vocab.json: {e}")

    VOCAB_LIST, saved_speed = load_data()

    # CLASS UI
    class Button:
        def __init__(self, txt, pos, width=260, height=40, font_obj=font, color="#00C3FF"):
            self.text = txt
            self.pos = pos 
            self.width = width
            self.height = height
            self.font = font_obj
            self.color = color
            self.rect = pygame.Rect(self.pos[0], self.pos[1], self.width, self.height)

        def draw(self, surface):
            pygame.draw.rect(surface, self.color, self.rect, 0, 5)
            pygame.draw.rect(surface, "#005EFF", self.rect, 2, 5)
            text_surface = self.font.render(self.text, True, 'white')
            text_rect = text_surface.get_rect(center=self.rect.center)
            surface.blit(text_surface, text_rect)

        def is_clicked(self, event, mouse_pos):
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.rect.collidepoint(mouse_pos):
                    return True
            return False

    class InputBox:
        def __init__(self, x, y, w, h, placeholder="", default_text=""):
            self.rect = pygame.Rect(x, y, w, h)
            self.color_inactive = pygame.Color('lightskyblue3')
            self.color_active = pygame.Color('dodgerblue2')
            self.color = self.color_inactive
            self.text = default_text
            self.placeholder = placeholder
            self.active = False

        def handle_event(self, event, mouse_pos):
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.rect.collidepoint(mouse_pos):
                    self.active = True
                else:
                    self.active = False
                self.color = self.color_active if self.active else self.color_inactive

            if self.active:
                if event.type == pygame.TEXTINPUT:
                    if len(self.text) < 25:
                        self.text += event.text
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        self.text = self.text[:-1]

        def draw(self, surface):
            pygame.draw.rect(surface, (20, 20, 30), self.rect, 0, 4)
            pygame.draw.rect(surface, self.color, self.rect, 2, 4)
            
            display_txt = self.text if self.text != "" else (self.placeholder if not self.active else "")
            txt_color = (255, 255, 255) if self.text != "" else (120, 120, 140)
            
            txt_surface = small_font.render(display_txt, True, txt_color)
            surface.blit(txt_surface, (self.rect.x + 8, self.rect.y + 8))

    # Nút bấm & Ô nhập liệu (Căn chỉnh theo 960x540)
    btn_start = Button("Start Game", (350, 200))
    btn_guide = Button("Guide", (350, 260))
    btn_exit = Button("Exit Game", (350, 320))
    btn_back = Button("Back", (350, 460))
    btn_vocab_back = Button("Back", (20, 20), width=90, height=35, font_obj=small_font, color="#6C757D")
    btn_in_game_back = Button("Back", (840, 10), width=100, height=35, font_obj=small_font)

    input_en = InputBox(80, 110, 320, 36, "Ví dụ: COMPUTER")
    input_vi = InputBox(80, 180, 320, 36, "Ví dụ: Máy Tính")
    input_speed = InputBox(80, 250, 320, 36, placeholder="Tốc độ (1-10)", default_text=str(saved_speed))

    btn_add_word = Button("Add Word", (80, 305), width=320, height=38, font_obj=small_font, color="#00BBFF")
    btn_clear_vocab = Button("Clear All", (80, 355), width=320, height=38, font_obj=small_font, color="#FA7B26")
    btn_play_now = Button("PLAY GAME", (350, 450), width=260, height=50, font_obj=font, color="#0E1F38")

    # Player Setup
    try:
        playerImg = pygame.image.load(resource_path('image/plane.png')).convert_alpha()
    except Exception:
        playerImg = pygame.Surface((64, 64))
        playerImg.fill((0, 255, 0))

    PLAYER_WIDTH = playerImg.get_width()
    PLAYER_HEIGHT = playerImg.get_height()
    PLAYER_SPEED = 450.0

    playerX = (VIRTUAL_WIDTH - PLAYER_WIDTH) / 2.0
    playerY = 430.0

    def player(surface, x, y):
        surface.blit(playerImg, (int(x), int(y)))

    # Bullet Setup
    try:
        bulletImg = pygame.image.load(resource_path('image/bullet.png')).convert_alpha()
    except Exception:
        bulletImg = pygame.Surface((16, 32))
        bulletImg.fill((255, 255, 0))

    BULLET_WIDTH = bulletImg.get_width()
    BULLET_HEIGHT = bulletImg.get_height()

    bulletX = 0.0
    bulletY = 430.0
    BULLET_SPEED = 600.0
    bullet_state = "ready"

    def fire_bullet(surface, x, y):
        nonlocal bullet_state
        bullet_state = "fire"
        surface.blit(bulletImg, (int(x), int(y)))

    def isCollision(enemy_x, enemy_y, word_text, bullet_x, bullet_y):
        w_width, w_height = word_font.size(word_text)
        word_rect = pygame.Rect(enemy_x, enemy_y, w_width, w_height).inflate(12, 8)
        bullet_rect = pygame.Rect(bullet_x, bullet_y, BULLET_WIDTH, BULLET_HEIGHT)
        return word_rect.colliderect(bullet_rect)

    # Enemy Word Setup
    enemy_reserve = []
    enemy_active = []
    hit_effects = []
    num_of_enemies = 0
    num_of_enemies_appear = 3

    def spawn_one_enemy():
        if len(enemy_reserve) > 0:
            index_random = random.randint(0, len(enemy_reserve) - 1)
            enemy_data = enemy_reserve.pop(index_random)
            enemy_active.append(enemy_data)

    def draw_enemy_word(surface, word_text, x, y, is_hit=False):
        color = "#FFC400" if is_hit else "#00E1FF"
        txt_surface = word_font.render(word_text, True, color)
        rect = txt_surface.get_rect(topleft=(int(x), int(y)))
        
        border_color = (255, 200, 0) if is_hit else (0, 150, 255)
        pygame.draw.rect(surface, (10, 10, 30), rect.inflate(12, 8), 0, 5)
        pygame.draw.rect(surface, border_color, rect.inflate(12, 8), 2, 5)
        surface.blit(txt_surface, rect)

    # Status & Render Display
    score_value = 0

    def show_score(surface, x, y):
        score = font.render(f"Score: {score_value}/{num_of_enemies}", True, (0, 255, 0))
        surface.blit(score, (x, y))

    def game_over_text(surface):
        over_text = over_font.render('GAME OVER', True, (255, 0, 0))
        rect = over_text.get_rect(center=(VIRTUAL_WIDTH // 2, 220))
        surface.blit(over_text, rect)

    def game_win_text(surface):
        win_text = win_font.render('YOU WIN!', True, (0, 255, 0))
        rect = win_text.get_rect(center=(VIRTUAL_WIDTH // 2, 220))
        surface.blit(win_text, rect)

    def reset_game_text(surface):
        reset_text = font.render('Press R to Reset Game', True, (0, 255, 0))
        rect = reset_text.get_rect(center=(VIRTUAL_WIDTH // 2, 290))
        surface.blit(reset_text, rect)

    def draw_danger_line(surface):
        danger_y = 390
        for x in range(0, VIRTUAL_WIDTH, 15):
            pygame.draw.line(surface, (255, 0, 0), (x, danger_y), (x + 8, danger_y), 2)
        danger_text = tiny_font.render("DANGER LINE", True, (255, 50, 50))
        surface.blit(danger_text, (10, danger_y - 18))

    def show_guide(surface):
        title = over_font.render('HOW TO PLAY', True, "#75C0FA")
        rect = title.get_rect(center=(VIRTUAL_WIDTH // 2, 50))
        surface.blit(title, rect)

        guide_box = pygame.Rect(80, 100, 800, 330)
        pygame.draw.rect(surface, (10, 25, 50), guide_box, 0, 10)
        pygame.draw.rect(surface, (0, 180, 255), guide_box, 3, 10)

        instructions = [
            "- Di chuyển: A,S,D,W hoặc phím mũi tên",
            "- Bắn: phím Space hoặc click chuột ",
            "- Lưu ý chỉ có thể bắn tiếp khi đạn đã bay ra khỏi màn hình",
            "- Nếu để Word vượt qua danger line sẽ thua",
            "- Word speed: Chỉ số càng lớn tốc độ chạy của chữ sẽ càng nhanh"
        ]
        
        y_offset = 125
        for line in instructions:
            txt_surface = guide_font.render(line, True, (255, 255, 255))
            surface.blit(txt_surface, (100, y_offset))
            y_offset += 42
            
        btn_back.draw(surface)

    def show_custom_vocab_screen(surface):
        btn_vocab_back.draw(surface)

        title = font.render('VOCABULARY LIST', True, (255, 255, 255))
        surface.blit(title, (480, 40))

        lbl_en = small_font.render("English Word:", True, (200, 220, 255))
        lbl_vi = small_font.render("Vietnamese Meaning:", True, (200, 220, 255))
        lbl_speed = small_font.render("Word Speed (Default: 1.8):", True, (200, 220, 255))
        
        surface.blit(lbl_en, (80, 85))
        surface.blit(lbl_vi, (80, 155))
        surface.blit(lbl_speed, (80, 225))

        input_en.draw(surface)
        input_vi.draw(surface)
        input_speed.draw(surface)
        
        btn_add_word.draw(surface)
        btn_clear_vocab.draw(surface)

        list_box = pygame.Rect(480, 85, 400, 340)
        pygame.draw.rect(surface, (15, 15, 30), list_box, 0, 5)
        pygame.draw.rect(surface, (0, 150, 255), list_box, 2, 5)

        lbl_list = small_font.render(f"Current List ({len(VOCAB_LIST)} words):", True, (0, 255, 200))
        surface.blit(lbl_list, (495, 95))

        start_idx = max(0, len(VOCAB_LIST) - 10)
        y_pos = 130
        for item in VOCAB_LIST[start_idx:]:
            txt_item = tiny_font.render(f"• {item['en']} : {item['vi']}", True, (230, 230, 230))
            surface.blit(txt_item, (495, y_pos))
            y_pos += 26

        btn_play_now.draw(surface)

    def parse_speed_input():
        try:
            val = float(input_speed.text.strip())
            return val if val > 0 else 1.8
        except ValueError:
            return 1.8

    def reset_game():
        nonlocal playerX, playerY, bulletX, bulletY, bullet_state
        nonlocal score_value, game_over, over_sound, game_win, win_sound
        nonlocal enemy_reserve, enemy_active, hit_effects, num_of_enemies

        playerX = (VIRTUAL_WIDTH - PLAYER_WIDTH) / 2.0
        playerY = 430.0

        bulletX = 0.0
        bulletY = 430.0
        bullet_state = "ready"

        score_value = 0
        game_over = False
        over_sound = True
        game_win = False
        win_sound = True

        word_speed = parse_speed_input()
        save_data(VOCAB_LIST, word_speed)
        safe_play_music()

        enemy_reserve.clear()
        enemy_active.clear()
        hit_effects.clear()

        base_list = VOCAB_LIST if len(VOCAB_LIST) > 0 else default_vocab_list
        vocab_to_use = base_list * 2
        num_of_enemies = len(vocab_to_use)

        base_pixel_speed = word_speed * 120

        for item in vocab_to_use:
            enemy_reserve.append({
                'en': item['en'].upper(),
                'vi': item['vi'],
                'x': float(random.randint(50, 700)),
                'y': float(random.randint(30, 100)),
                'x_change': base_pixel_speed,
                'y_change': 35.0
            })

        for _ in range(min(num_of_enemies_appear, len(enemy_reserve))):
            spawn_one_enemy()

    # Trạng thái Game
    main_menu = True
    vocab_screen = False
    guide_screen = False
    running = True
    game_over = False
    over_sound = True
    game_win = False
    win_sound = True

    def toggle_fullscreen():
        nonlocal screen, is_fullscreen
        is_fullscreen = not is_fullscreen
        if is_fullscreen:
            screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            screen = pygame.display.set_mode((VIRTUAL_WIDTH, VIRTUAL_HEIGHT), pygame.RESIZABLE)

    # ----------------------------------------------------
    # MAIN GAME LOOP (ASYNCIO COMPATIBLE)
    # ----------------------------------------------------
    while running:
        dt = clock.tick(TARGET_FPS) / 1000.0
        if dt > 0.1:
            dt = 0.1

        raw_mouse_pos = pygame.mouse.get_pos()
        virtual_mouse_pos = scale_mouse_pos(raw_mouse_pos)

        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                running = False

            # Bật âm thanh ở lượt tương tác đầu tiên của người dùng
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                unlock_audio()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F11 or (event.key == pygame.K_RETURN and (event.mod & pygame.KMOD_ALT)):
                    toggle_fullscreen()
                elif event.key == pygame.K_ESCAPE and is_fullscreen:
                    toggle_fullscreen()

            if main_menu:
                if btn_start.is_clicked(event, virtual_mouse_pos):
                    main_menu = False
                    vocab_screen = True
                elif btn_guide.is_clicked(event, virtual_mouse_pos):
                    main_menu = False
                    guide_screen = True
                elif btn_exit.is_clicked(event, virtual_mouse_pos):
                    running = False

            elif vocab_screen:
                input_en.handle_event(event, virtual_mouse_pos)
                input_vi.handle_event(event, virtual_mouse_pos)
                input_speed.handle_event(event, virtual_mouse_pos)

                if btn_vocab_back.is_clicked(event, virtual_mouse_pos):
                    vocab_screen = False
                    main_menu = True

                is_add_clicked = btn_add_word.is_clicked(event, virtual_mouse_pos)
                is_enter_pressed = (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN and not input_speed.active)

                if is_add_clicked or is_enter_pressed:
                    if input_en.text.strip() != "" and input_vi.text.strip() != "":
                        VOCAB_LIST.append({
                            "en": input_en.text.strip().upper(),
                            "vi": input_vi.text.strip()
                        })
                        current_spd = parse_speed_input()
                        save_data(VOCAB_LIST, current_spd)
                        input_en.text = ""
                        input_vi.text = ""

                elif btn_clear_vocab.is_clicked(event, virtual_mouse_pos):
                    VOCAB_LIST.clear()
                    current_spd = parse_speed_input()
                    save_data(VOCAB_LIST, current_spd)

                elif btn_play_now.is_clicked(event, virtual_mouse_pos):
                    vocab_screen = False
                    reset_game()

            elif guide_screen:
                if btn_back.is_clicked(event, virtual_mouse_pos):
                    guide_screen = False
                    main_menu = True

            else:
                if btn_in_game_back.is_clicked(event, virtual_mouse_pos):
                    main_menu = True
                    safe_stop_music()

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if not game_over and not game_win:
                        if not btn_in_game_back.rect.collidepoint(virtual_mouse_pos):
                            if bullet_state == "ready":
                                safe_play_sound(laser_sound)
                                bulletX = playerX + (PLAYER_WIDTH - BULLET_WIDTH) / 2.0
                                bulletY = playerY - BULLET_HEIGHT / 2.0
                                bullet_state = "fire"

                if event.type == pygame.KEYDOWN:
                    if (game_over or game_win) and event.key == pygame.K_r:
                        reset_game()

                    if not game_over and not game_win and event.key == pygame.K_SPACE:
                        if bullet_state == "ready":
                            safe_play_sound(laser_sound)
                            bulletX = playerX + (PLAYER_WIDTH - BULLET_WIDTH) / 2.0
                            bulletY = playerY - BULLET_HEIGHT / 2.0
                            bullet_state = "fire"

        # Game Logic
        if not main_menu and not vocab_screen and not guide_screen:
            if not game_over and not game_win:
                keys = pygame.key.get_pressed()
                dx, dy = 0, 0
                if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                    dx -= 1
                if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                    dx += 1
                if keys[pygame.K_UP] or keys[pygame.K_w]:
                    dy -= 1
                if keys[pygame.K_DOWN] or keys[pygame.K_s]:
                    dy += 1

                if dx != 0 and dy != 0:
                    dx *= 0.7071
                    dy *= 0.7071

                playerX += dx * PLAYER_SPEED * dt
                playerY += dy * PLAYER_SPEED * dt

                playerX = max(0, min(playerX, VIRTUAL_WIDTH - PLAYER_WIDTH))
                playerY = max(390, min(playerY, VIRTUAL_HEIGHT - PLAYER_HEIGHT))

                if bullet_state == "fire":
                    bulletY -= BULLET_SPEED * dt
                    if bulletY + BULLET_HEIGHT <= 0:
                        bullet_state = "ready"

                for i in range(len(enemy_active) - 1, -1, -1):
                    e = enemy_active[i]
                    e['x'] += e['x_change'] * dt

                    word_w, _ = word_font.size(e['en'])

                    if e['x'] <= 5:
                        e['x_change'] = abs(e['x_change'])
                        e['y'] += e['y_change']
                    elif e['x'] + word_w >= VIRTUAL_WIDTH - 15:
                        e['x_change'] = -abs(e['x_change'])
                        e['y'] += e['y_change']

                    if e['y'] > 360:
                        game_over = True
                        break

                    if bullet_state == "fire" and isCollision(e['x'], e['y'], e['en'], bulletX, bulletY):
                        safe_play_sound(explosion_sound)
                        bullet_state = "ready"
                        score_value += 1

                        full_text = f"{e['en']} : {e['vi']}"
                        eff_w, _ = word_font.size(full_text)
                        eff_x = max(10, min(e['x'], VIRTUAL_WIDTH - eff_w - 20))

                        hit_effects.append({
                            'text': full_text,
                            'x': eff_x,
                            'y': e['y'],
                            'timer': 2.0
                        })

                        enemy_active.pop(i)
                        spawn_one_enemy()

                        if score_value >= num_of_enemies:
                            game_win = True
                        break

        # Render
        canvas.blit(background, (0, 0))

        if main_menu:
            txt_title = over_font.render('WORD SHOOTER', True, (255, 255, 255))
            rect_title = txt_title.get_rect(center=(VIRTUAL_WIDTH // 2, 110))
            canvas.blit(txt_title, rect_title)
            btn_start.draw(canvas)
            btn_guide.draw(canvas)
            btn_exit.draw(canvas)

        elif vocab_screen:
            show_custom_vocab_screen(canvas)

        elif guide_screen:
            show_guide(canvas)

        else:
            draw_danger_line(canvas)

            for e in enemy_active:
                draw_enemy_word(canvas, e['en'], e['x'], e['y'])

            if bullet_state == "fire":
                fire_bullet(canvas, bulletX, bulletY)

            for effect in hit_effects[:]:
                draw_enemy_word(canvas, effect['text'], effect['x'], effect['y'], is_hit=True)
                effect['y'] -= 20 * dt
                effect['timer'] -= dt
                if effect['timer'] <= 0:
                    hit_effects.remove(effect)

            if game_over:
                game_over_text(canvas)
                reset_game_text(canvas)
                if over_sound:
                    safe_play_sound(gameover_sound)
                    safe_stop_music()
                    over_sound = False 

            elif game_win:
                game_win_text(canvas)
                reset_game_text(canvas)
                if win_sound:
                    safe_play_sound(gamewin_sound)
                    safe_stop_music()
                    win_sound = False

            player(canvas, playerX, playerY)
            show_score(canvas, 10, 10)
            btn_in_game_back.draw(canvas)

        # ----------------------------------------------------
        # SCALING RENDER RA MÀN HÌNH CHÍNH (XÓA VIỀN DƯ THỪA)
        # ----------------------------------------------------
        screen.fill((0, 0, 0))
        off_x, off_y, _, new_w, new_h = get_render_offset_and_scale()
        scaled_canvas = pygame.transform.smoothscale(canvas, (new_w, new_h))
        screen.blit(scaled_canvas, (off_x, off_y))

        pygame.display.update()

        # Nhường quyền xử lý cho Trình duyệt / Event loop
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())